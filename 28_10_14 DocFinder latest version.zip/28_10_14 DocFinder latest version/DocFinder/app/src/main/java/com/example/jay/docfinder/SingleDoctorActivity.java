package com.example.jay.docfinder;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.content.Intent;
import android.widget.TextView;


public class SingleDoctorActivity extends ActionBarActivity {

    // JSON Node names
    private static final String TAG_FIRST_NAME = "frst_nm";
    private static final String TAG_LAST_NAME = "lst_nm";
    private static final String TAG_GENDER = "gndr";
    private static final String TAG_PRIMARY_SPECIALITY = "pri_spec";
    private static final String TAG_GRADUATION_YEAR = "grd_yr";
    private static final String TAG_PAC_ID = "ind_pac_id";
    private static final String TAG_MEDICAL_SCHOOL_NAME = "med_sch";
    private static final String TAG_ADDRESS = "adr_ln_1";
    private static final String TAG_CITY = "cty";
    private static final String TAG_STATE = "st";
    private static final String TAG_ZIPCODE = "zip";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_single_doctor);

        TextView txtFirstName = (TextView) findViewById(R.id.frst_nm);
        TextView txtLastName = (TextView) findViewById(R.id.lst_nm);
        TextView txtGender = (TextView) findViewById(R.id.gndr);
//        TextView txtCredential = (TextView) findViewById(R.id.cred);
        TextView txtSpeciality = (TextView) findViewById(R.id.pri_spec);
        TextView txtGraduationYear = (TextView) findViewById(R.id.grd_yr);
        TextView txtID = (TextView) findViewById(R.id.ind_pac_id);
        TextView txtMedicalSchool = (TextView) findViewById(R.id.med_sch);
        TextView txtAddress = (TextView) findViewById(R.id.adr_ln_1);
//        TextView txtCity = (TextView) findViewById(R.id.cty);
//        TextView txtState = (TextView) findViewById(R.id.st);
//        TextView txtZipcode = (TextView) findViewById(R.id.zip);

        Intent i = getIntent();
        // getting attached intent data
        String frst_nm = i.getStringExtra("frst_nm");
        String lst_nm = i.getStringExtra("lst_nm");
        String gndr = i.getStringExtra("gndr");
//        String cred = i.getStringExtra("cred");
        String pri_spec = i.getStringExtra("pri_spec");
        String grd_yr = i.getStringExtra("grd_yr");
        String ind_pac_id = i.getStringExtra("ind_pac_id");
//        String org_lgl_nm = i.getStringExtra("org_lgl_nm");
        String med_sch= i.getStringExtra("med_sch");
        String adr_ln_1 = i.getStringExtra("adr_ln_1");
        //String adr_ln_2 = i.getStringExtra("adr_ln_2");
        String cty = i.getStringExtra("cty");
        String st = i.getStringExtra("st");
        String zip = i.getStringExtra("zip");
        String fname =   "First Name      : " + frst_nm;
        String lname =   "Last Name      : " + lst_nm;
        String gender =  "Gender             : " + gndr;
        String spec =    "Speciality        : " + pri_spec;
        String year =    "Grad Year        : " +grd_yr;
        String pac_id =  "ID                      : " + ind_pac_id;
        String school =  "Med School     : " + med_sch;
        if (zip.length() > 5) {
            adr_ln_1 = adr_ln_1 + ", " + cty + ", " + st + " " + zip.substring(0, 5) + "-" + zip.substring(5);
        } else {
            adr_ln_1 = adr_ln_1 + ", " + cty + ", " + st + " " + zip;
        }
//        String addres =  "Address           : " + adr_ln_1;
//        String city =    "                            " + cty;
//        String state =   "                            " + st;
//        String zipcode = "                            " + zip;

        //      displaying selected product name
        txtFirstName.setText(fname);
        txtLastName.setText(lname);
        txtGender.setText(gender);
//        txtCredential.setText(cred);
        txtSpeciality.setText(spec);
        txtGraduationYear.setText(year);
        txtID.setText(pac_id);
        txtMedicalSchool.setText(school);
        txtAddress.setText(adr_ln_1);
//        txtCity.setText(city);
//        txtState.setText(state);
//        txtZipcode.setText(zipcode);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.single_doctor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}