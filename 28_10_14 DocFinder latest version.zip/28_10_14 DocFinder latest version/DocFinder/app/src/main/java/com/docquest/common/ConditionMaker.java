package com.docquest.common;

import android.util.Log;

import com.docquest.common.util.HTTPRequestHandler;

public class ConditionMaker {
    String url = "";
    String condition = "";
    String finalurl = "";


    //Get Data should return parent to Search Result Page
//    public Parent getData(String type, String[] strParam) {
    public void getData(String type, String[] strParam) {

        try {
            if (type.equalsIgnoreCase("Hospital")) {
                System.out.println("Loading Hospital Data.....");
                url = "http://data.medicare.gov/resource/xubh-q36u.json?";
                condition = "$limit=5&$offset=0&state=GA";
                condition = getCondition(type, strParam);
                //condition="$limit=2&$offset=0&st=GA";
                finalurl = url + condition;
                System.out.println("Request for " + type + ":"
                        + finalurl);

            } else if (type.equalsIgnoreCase("Doctor")) {
                System.out.println("Loading Doctor Data.....");
                url = "http://data.medicare.gov/resource/s63f-csi6.json?";
                condition = getCondition(type, strParam);
                // condition="$limit=2&$offset=0&st=GA";
                finalurl = url + condition;
                System.out.println("Request for " + type + ":"
                        + finalurl);

                //System.exit(0);
            }

            HTTPRequestHandler http = new HTTPRequestHandler();

            System.out.println("Request for " + type + ":"
                    + finalurl);
            System.out.println("Testing 1 - Send Http GET request");
            //http.sendGet(finalurl);
            String jsonParentString = http.sendGet(finalurl);
            System.out.println("Testing 2 - Send Http GET request");
            // In Search Result Page
            GsonParentDeserializer gp = new GsonParentDeserializer();
            Parent p = gp.gsonParent(jsonParentString, type);

            //Put this logic in the Search Page
            //Pass param Type, Parent and create a new object for GsonParentDeserializer
            if (p != null) {
                for (String child : p.getParent()) {
                    if (child != "" && type.equalsIgnoreCase("Doctor")) {
                        Doctor d = gp.gsonChildDoctor(child);
                        d.displayDoctorContent(d);  //Temporary display of content
                        System.out.println("Doctor Name : Dr. " + d.getLastName() + ", " + d.getFirstName());
                    } else if (child != "" && type.equalsIgnoreCase("Hospital")) {
                        Hospital h = gp.gsonChildHospital(child);
                        h.displayHospitalContent(h); //Temporary display of content
                        System.out.println("Hospital Name : " + h.getHospital_name());
                    } else {
                        System.out.println("No " + type + " in the List Returned");
                    }
                }
            }
        } catch (Exception e) {
//            Log.d("ERROR", e.getMessage());
            System.out.println("ERROR"+ e.getMessage());

        }
    }

    public String getCondition(String type, String[] params) {
        //String condition="$where=zip_code='30720' OR zip_code='30286' &$limit=5&$offset=0";
        String condition = "";

        for (String p : params) {
            String[] t = p.split("=");
            if (t.length <= 1)
                continue;
            if (type.equalsIgnoreCase("Hospital")) {
                if (t[0].equalsIgnoreCase("zipcode")) {
                    condition += "$where=";
                    if (t[1].contains(",")) {
                        String[] zipcodes = t[1].split(",");
                        for (int i = 0; i < zipcodes.length; i++) {
                            if (i < zipcodes.length - 1) {
                                condition += "zip_code='" + zipcodes[i]
                                        + "' OR ";
                            } else {
                                condition += "zip_code='" + zipcodes[i] + "'";
                            }
                        }
                    } else {
                        condition += "zip_code=" + t[1];
                    }
                } else if (t[0].equalsIgnoreCase("City")) {
                    condition += "city=" + t[1];
                } else if (t[0].equalsIgnoreCase("State")) {
                    condition += "state=" + t[1];
                } else if (t[0].equalsIgnoreCase("limit")) {
                    condition += "$limit=" + t[1];
                } else if (t[0].equalsIgnoreCase("offset")) {
                    condition += "$offset=" + t[1];
                } else if (t[0].equalsIgnoreCase("name")) {
                    condition += "hospital_name=" + t[1];
                }
                condition += "&";
            } else if (type.equalsIgnoreCase("Doctor")) {
                if (t[0].equalsIgnoreCase("zipcode")) {
                    condition += "$where=";
                    if (t[1].contains(",")) {
                        String[] zipcodes = t[1].split(",");
                        for (int i = 0; i < zipcodes.length; i++) {
                            if (i < zipcodes.length - 1) {
                                condition += "zip='" + zipcodes[i] + "' OR ";
                            } else {
                                condition += "zip='" + zipcodes[i] + "'";
                            }
                        }
                    } else {
                        condition += "zip=" + t[1];
                    }
                } else if (t[0].equalsIgnoreCase("City")) {
                    condition += "cty=" + t[1];
                } else if (t[0].equalsIgnoreCase("State")) {
                    condition += "st=" + t[1];
                } else if (t[0].equalsIgnoreCase("limit")) {
                    condition += "$limit=" + t[1];
                } else if (t[0].equalsIgnoreCase("offset")) {
                    condition += "$offset=" + t[1];
                } else if (t[0].equalsIgnoreCase("Firstname")) {
                    condition += "frst_nm=" + t[1];
                } else if (t[0].equalsIgnoreCase("Lastname")) {
                    condition += "lst_nm=" + t[1];
                } else if (t[0].equalsIgnoreCase("Gender")) {
                    condition += "gndr=" + t[1];
                } else if (t[0].equalsIgnoreCase("Speciality")) {
                    condition += "pri_spec=" + t[1];
                }
                condition += "&";
            }
        }
        System.out.println("Condition is " + condition);
        return condition;
    }
}
