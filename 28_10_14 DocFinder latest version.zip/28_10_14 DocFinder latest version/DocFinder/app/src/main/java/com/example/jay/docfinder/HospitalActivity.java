package com.example.jay.docfinder;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.docquest.common.ConditionMaker;
import com.docquest.common.util.HTTPRequestHandler;

public class HospitalActivity extends ActionBarActivity implements View.OnClickListener{

    Button search;
    EditText hospital;
    EditText zipcode;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);
        search=(Button)findViewById(R.id.buttonHosSearch);

        // Capture button clicks

        search.setOnClickListener(this);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.hospital, menu);
        //return true;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case R.id.action_home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void buttonHosSearchClick()
    {
        hospital   = (EditText)findViewById(R.id.hospitalEditText);
        zipcode   = (EditText)findViewById(R.id.hospitalzipcodeEditText);
        //startActivity(new Intent(getApplicationContext(),SearchHospitalActivity.class));
        Intent in = new Intent(getApplicationContext(),
                SearchHospitalActivity.class);
        String zc = zipcode.getText().toString();
        String hn = hospital.getText().toString();
        in.putExtra("zipcode",zc);
        in.putExtra("hospitalname", hn);
        startActivity(in);


    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {

            case R.id.buttonHosSearch:
                buttonHosSearchClick();
                break;


        }

    }
}
