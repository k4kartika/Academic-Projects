package com.docquest.common;

import java.lang.reflect.Type;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class Hospital {
	
    private String hospital_name;
	private String zip_code;
	private String address;
	private String provider_id;
	private String hospital_ownership;
	private String hospital_type;
	private String state;
	private String emergency_services;
	private String county_name;
	private String city;
	private JsonObject location;
	private JsonObject phone_number;
	
	public String getHospital_name() {
		return hospital_name;
	}

	public void setHospital_name(String hospital_name) {
		this.hospital_name = hospital_name;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getProvider_id() {
		return provider_id;
	}

	public void setProvider_id(String provider_id) {
		this.provider_id = provider_id;
	}

	public String getHospital_ownership() {
		return hospital_ownership;
	}

	public void setHospital_ownership(String hospital_ownership) {
		this.hospital_ownership = hospital_ownership;
	}

	public String getHospital_type() {
		return hospital_type;
	}

	public void setHospital_type(String hospital_type) {
		this.hospital_type = hospital_type;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEmergency_services() {
		return emergency_services;
	}

	public void setEmergency_services(String emergency_services) {
		this.emergency_services = emergency_services;
	}

	public String getCounty_name() {
		return county_name;
	}

	public void setCounty_name(String county_name) {
		this.county_name = county_name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public JsonObject getLocation() {
		return location;
	}

	public void setLocation(JsonObject location) {
		this.location = location;
	}

	public JsonObject getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(JsonObject phone_number) {
		this.phone_number = phone_number;
	}
	
	public void displayHospitalContent (Hospital hospital){
        System.out.println("De-Serialized Hospital Object ::"+hospital);
        System.out.println("Name ::"+hospital.getHospital_name());
        System.out.println("zip_code ::"+hospital.getZip_code());
        System.out.println("address ::"+hospital.getAddress());
        System.out.println("provider_id ::"+hospital.getProvider_id());
        System.out.println("hospital_ownership ::"+hospital.getHospital_ownership());
        System.out.println("hospital_type ::"+hospital.getHospital_type());
        System.out.println("state ::"+hospital.getState());
        System.out.println("emergency_services ::"+hospital.getEmergency_services());
        System.out.println("county_name ::"+hospital.getCounty_name());
        System.out.println("city ::"+hospital.getCity());
        System.out.println("location longitude ::"+hospital.getLocation().get("longitude").getAsString());
        System.out.println("location latitude  ::"+hospital.getLocation().get("latitude").getAsString());
        System.out.println("phone_number ::"+hospital.getPhone_number().get("phone_number").getAsString());
        System.out.println("-----------------------------------------------------------------");
        System.out.println("");
    }
	
}
 
class HospitalDeserializer implements JsonDeserializer<Hospital>
{
    public Hospital deserialize(JsonElement json, Type type, JsonDeserializationContext deserializeContext) throws JsonParseException {
         
        JsonObject jsonObject=json.getAsJsonObject();
        
        String hospital_name=jsonObject.get("hospital_name").getAsString();
        String zip_code=jsonObject.get("zip_code").getAsString();
        String address=jsonObject.get("address").getAsString();
        String provider_id=jsonObject.get("provider_id").getAsString();
        String hospital_ownership=jsonObject.get("hospital_ownership").getAsString();
        String hospital_type=jsonObject.get("hospital_type").getAsString();
        String state=jsonObject.get("state").getAsString();
        String emergency_services=jsonObject.get("emergency_services").getAsString();
        String county_name=jsonObject.get("county_name").getAsString();
        String city=jsonObject.get("city").getAsString();
        JsonObject location=jsonObject.get("location").getAsJsonObject();
        JsonObject phone_number=jsonObject.get("phone_number").getAsJsonObject();
         
        Hospital hospital=new Hospital();
        hospital.setHospital_name(hospital_name);
        hospital.setZip_code(zip_code);
        hospital.setAddress(address);
        hospital.setProvider_id(provider_id);
        hospital.setHospital_ownership(hospital_ownership);
        hospital.setHospital_type(hospital_type);
        hospital.setState(state);
        hospital.setEmergency_services(emergency_services);
        hospital.setCounty_name(county_name);
        hospital.setCity(city);
        hospital.setLocation(location);
        hospital.setPhone_number(phone_number);
      
        return hospital;
    }
}