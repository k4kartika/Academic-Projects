package com.example.jay.docfinder;

import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.content.Intent;
import android.widget.TextView;


public class SingleHospitalActivity extends ActionBarActivity {

    private static final String TAG_HOSPITAL_NAME = "hospital_name";
    private static final String TAG_ADDRESS = "haddress";
    private static final String TAG_CITY = "hcity";
    private static final String TAG_STATE = "hstate";
    private static final String TAG_ZIPCODE = "zip_code";
    private static final String TAG_PHONE_NUMBER = "phone_number";
    private static final String TAG_HOSPITAL_TYPE = "hospital_type";
    private static final String TAG_PROVIDER_NUMBER = "provider_id";
    private static final String TAG_EMERGENCY_SERVICES = "emergency_services";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.activity_single_hospital);

        TextView txtHospitalName = (TextView) findViewById(R.id.hospital_name);
        TextView txtAddress = (TextView) findViewById(R.id.haddress);
        //TextView txtCity = (TextView) findViewById(R.id.hcity);
        //TextView txtState = (TextView) findViewById(R.id.hstate);
        //TextView txtZipcode = (TextView) findViewById(R.id.zip_code);
        TextView txtPhoneNumber = (TextView) findViewById(R.id.phone_number);
        TextView txtType = (TextView) findViewById(R.id.hospital_type);
        TextView txtProviderName = (TextView) findViewById(R.id.provider_id);
        TextView txtEmergency = (TextView) findViewById(R.id.emergency_services);

        Intent i = getIntent();
        // getting attached intent data
        String hospital_name = i.getStringExtra("hospital_name");
        String haddress = i.getStringExtra("address");
        String hcity = i.getStringExtra("city");
        String hstate = i.getStringExtra("state");
        String hzip_code = i.getStringExtra("zip_code");
        String hphone_number = i.getStringExtra("phone_number");
        String hhospital_type = i.getStringExtra("hospital_type");
        String hprovider_id = i.getStringExtra("provider_id");
        String hemergency_services = i.getStringExtra("emergency_services");
        String address = haddress +  ", " + hcity  + ", " + hstate  + " " + hzip_code ;
        //String city = "                   " + hcity;
        //String state = "                   " + hstate;
        //String zip_code = "                   " + hzip_code;
        String phone_number = "Phone     : " + hphone_number;
        String hospital_type = "Type        : " + hhospital_type;
        String provider_id = "ID             : " + hprovider_id;
        String emergency_services;
        if (hemergency_services.equals("true")) {
            emergency_services = "EMS        : YES";
        }
        else {
            emergency_services = "EMS        : NO";
        }
        // displaying selected product name
        txtHospitalName.setText(hospital_name);
        txtAddress.setText(address);
        //txtCity.setText(city);
        //txtState.setText(state);
        //txtZipcode.setText(zip_code);
        txtPhoneNumber.setText(phone_number);
        txtType.setText(hospital_type);
        txtProviderName.setText(provider_id);
        txtEmergency.setText(emergency_services);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.single_hospital, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}