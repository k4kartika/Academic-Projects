package com.example.jay.docfinder;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import java.util.Iterator;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


public class SearchDoctorActivity extends ListActivity {

    private ProgressDialog pDialog;

    // URL to get contacts JSON

  //  private static String url = "http://data.medicare.gov/resource/wan4-m8eu.json?&zip=30144&";
  //  private static String url = "http://data.medicare.gov/resource/wan4-m8eu.json?$q=30144";
    private static String url ="http://data.medicare.gov/resource/s63f-csi6.json?";

  private static String final_url;


    // JSON Node names
    private static final String TAG_FIRST_NAME = "frst_nm";
    private static final String TAG_LAST_NAME = "lst_nm";
    private static final String TAG_GENDER = "gndr";
    private static final String TAG_CREDENTIAL = "cred";
    private static final String TAG_PRIMARY_SPECIALITY = "pri_spec";
    private static final String TAG_GRADUATION_YEAR = "grd_yr";
    private static final String TAG_PAC_ID = "ind_pac_id";
    private static final String TAG_ORGANIZATION_LEGAL_NAME = "org_lgl_nm";
    private static final String TAG_MEDICAL_SCHOOL_NAME = "med_sch";
    private static final String TAG_ADDRESS = "adr_ln_1";
    private static final String TAG_ADDRESS2 = "adr_ln_2";
    private static final String TAG_CITY = "cty";
    private static final String TAG_STATE = "st";
    private static final String TAG_ZIPCODE = "zip";

    // contacts JSONArray
    JSONObject c = null;

    // Hashmap for ListView
    ArrayList<HashMap<String, String>> contactList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_doctor);

        contactList = new ArrayList<HashMap<String, String>>();

        ListView lv = getListView();
        Intent i = getIntent();
        // getting attached intent data
        String zip_code = i.getStringExtra("zipcode");
        String doctor_name = i.getStringExtra("doctorname");
        String spec = i.getStringExtra("speciality");
        String speciality = spec.replaceAll(" ","%20");
        if ((!zip_code.isEmpty()) && (!doctor_name.isEmpty()) && (!speciality.isEmpty()))
            final_url = url + "&zip=" + zip_code + "&frst_nm=" + doctor_name +  "&pri_spec=" + speciality;
        else if ((!zip_code.isEmpty()) && (!doctor_name.isEmpty()) && (speciality.isEmpty()))
            final_url = url + "&zip=" + zip_code + "&frst_nm=" + doctor_name;
        else if ((!zip_code.isEmpty()) && (doctor_name.isEmpty()) && (!speciality.isEmpty()))
            final_url = url + "&zip=" + zip_code +  "&pri_spec=" + speciality;
        else if ((zip_code.isEmpty()) && (!doctor_name.isEmpty()) && (!speciality.isEmpty()))
            final_url = url + "&frst_nm=" + doctor_name +  "&pri_spec=" + speciality;
        else if ((!zip_code.isEmpty()) && (doctor_name.isEmpty()) && (speciality.isEmpty()))
            final_url = url  + "&zip=" + zip_code;
        else if ((zip_code.isEmpty()) && (!doctor_name.isEmpty()) && (speciality.isEmpty()))
            final_url = url  + "&frst_nm=" + doctor_name;
        else if ((zip_code.isEmpty()) && (doctor_name.isEmpty()) && (!speciality.isEmpty()))
            final_url = url  + "&pri_spec=" + speciality;
        else
            final_url = url;

        System.out.println("doctor url : " + final_url);

        // Listview on item click listener
        lv.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // getting values from selected ListItem
                String name = ((TextView) view.findViewById(R.id.frst_nm))
                        .getText().toString();
                String last = ((TextView) view.findViewById(R.id.lst_nm))
                        .getText().toString();

//                String gender = ((TextView) view.findViewById(R.id.gndr))
//                        .getText().toString();
//                String credential = ((TextView) view.findViewById(R.id.cred))
//                        .getText().toString();
//                String spl = ((TextView) view.findViewById(R.id.pri_spec))
//                        .getText().toString();
//                String year = ((TextView) view.findViewById(R.id.grd_yr))
//                        .getText().toString();
//                String id_num = ((TextView) view.findViewById(R.id.ind_pac_id))
//                        .getText().toString();
//                String org = ((TextView) view.findViewById(R.id.org_lgl_nm))
//                        .getText().toString();
//                String school = ((TextView) view.findViewById(R.id.med_sch))
//                        .getText().toString();
//                String address = ((TextView) view.findViewById(R.id.adr_ln_1))
//                        .getText().toString();
//                String city = ((TextView) view.findViewById(R.id.cty))
//                        .getText().toString();
//                String state = ((TextView) view.findViewById(R.id.st))
//                        .getText().toString();
//                String zipcode = ((TextView) view.findViewById(R.id.zip))
//                        .getText().toString();


                String gender = "";
//                String credential = "";
                String spl = "";
                String year = "";
                String id_num = "";
//                String org = "";
                String school = "";
                String address = "";
                String city = "";
                String state = "";
                String zipcode = "";

                for (HashMap<String, String> map : contactList)  {
                    if(map.get(TAG_FIRST_NAME).contentEquals(name) && map.get(TAG_LAST_NAME).contentEquals(last)) {
                        gender = map.get(TAG_GENDER);
//                        credential = map.get(TAG_CREDENTIAL);
                        spl = map.get(TAG_PRIMARY_SPECIALITY);
                        year = map.get(TAG_GRADUATION_YEAR);
                        id_num = map.get(TAG_PAC_ID);
//                        org = map.get(TAG_ORGANIZATION_LEGAL_NAME);
                        school = map.get(TAG_MEDICAL_SCHOOL_NAME);
                        address = map.get(TAG_ADDRESS);
                        city = map.get(TAG_CITY);
                        state = map.get(TAG_STATE);
                        zipcode = map.get(TAG_ZIPCODE);
                    }

                }


                // Starting single contact activity
                Intent in = new Intent(getApplicationContext(),
                        SingleDoctorActivity.class);
                in.putExtra(TAG_FIRST_NAME, name);
                in.putExtra(TAG_LAST_NAME, last);
                in.putExtra(TAG_GENDER, gender);
//                in.putExtra(TAG_CREDENTIAL, credential);
                in.putExtra(TAG_PRIMARY_SPECIALITY, spl);
                in.putExtra(TAG_GRADUATION_YEAR, year);
                in.putExtra(TAG_PAC_ID, id_num);
//                in.putExtra(TAG_ORGANIZATION_LEGAL_NAME, org);
                in.putExtra(TAG_MEDICAL_SCHOOL_NAME, school);
                in.putExtra(TAG_ADDRESS, address);
                in.putExtra(TAG_CITY, city);
                in.putExtra(TAG_STATE, state);
                in.putExtra(TAG_ZIPCODE, zipcode);
                startActivity(in);

            }
        });

        // Calling async task to get json
        new GetContacts().execute();
    }
    /**
     * Async task class to get json by making HTTP call
     * */
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(SearchDoctorActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(final_url, ServiceHandler.GET);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
//                        JSONObject jsonObj = new JSONObject(jsonStr);
                    JSONArray jsonArr = new JSONArray(jsonStr);

                    // Getting JSON Array node

                    for (int i = 0; i < jsonArr.length(); i++) {
//                    for (int i = 0; i < 10; i++) {
                        c=jsonArr.getJSONObject(i);
                        String frst_nm = c.getString(TAG_FIRST_NAME);
                        String lst_nm = c.getString(TAG_LAST_NAME);
                        String gndr = c.getString(TAG_GENDER);
//                        String cred = c.getString(TAG_CREDENTIAL);
                        String pri_spec = c.getString(TAG_PRIMARY_SPECIALITY);
                        String grd_yr = c.getString(TAG_GRADUATION_YEAR);
                        String ind_pac_id = c.getString(TAG_PAC_ID);
//                        String org_lgl_nm = c.getString(TAG_ORGANIZATION_LEGAL_NAME);
                        String med_sch = c.getString(TAG_MEDICAL_SCHOOL_NAME);
                        String adr_ln_1 = c.getString(TAG_ADDRESS);
                        //String adr_ln_2 = c.getString(TAG_ADDRESS2);
                        String cty = c.getString(TAG_CITY);
                        String st = c.getString(TAG_STATE);
                        String zip = c.getString(TAG_ZIPCODE);
                        // tmp hashmap for single contact
                        HashMap<String, String> contact = new HashMap<String, String>();

                        // adding each child node to HashMap key => value
                        contact.put(TAG_FIRST_NAME, frst_nm);
                        contact.put(TAG_LAST_NAME, lst_nm);
                        contact.put(TAG_GENDER, gndr);
//                        contact.put(TAG_CREDENTIAL, cred);
                        contact.put(TAG_PRIMARY_SPECIALITY, pri_spec);
                        contact.put(TAG_GRADUATION_YEAR, grd_yr);
                        contact.put(TAG_PAC_ID, ind_pac_id);
//                        contact.put(TAG_ORGANIZATION_LEGAL_NAME, org_lgl_nm);
                        contact.put(TAG_MEDICAL_SCHOOL_NAME, med_sch);
                        contact.put(TAG_ADDRESS, adr_ln_1);
                        contact.put(TAG_CITY, cty);
                        contact.put(TAG_STATE, st);
                        contact.put(TAG_ZIPCODE, zip);

                        // adding contact to contact list
                        contactList.add(contact);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */
            ListAdapter adapter = new SimpleAdapter(
                    SearchDoctorActivity.this, contactList,
//                    R.layout.list_view, new String[] { TAG_FIRST_NAME, TAG_LAST_NAME}, new int[] { R.id.frst_nm, R.id.lst_nm});
                    R.layout.list_view_doctor, new String[] { TAG_FIRST_NAME, TAG_LAST_NAME, TAG_PRIMARY_SPECIALITY,
                    TAG_ADDRESS, TAG_ZIPCODE }, new int[] { R.id.frst_nm, R.id.lst_nm, R.id.pri_spec,
                    R.id.adr_ln_1, R.id.zip });

            setListAdapter(adapter);
        }

    }


}
