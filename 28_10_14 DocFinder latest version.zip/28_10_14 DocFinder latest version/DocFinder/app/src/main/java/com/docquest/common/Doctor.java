package com.docquest.common;

import java.lang.reflect.Type;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
 
public class Doctor {
	
	private String PACID;
	private String ProfessionalEnrollmentID;
	private String LastName;
	private String FirstName;
	private String Gender;
	private String MedicalSchoolName;
	private String PrimarySpeciality;
	private String AllSecondarySpecialities;
	private String Line1StreetAddress;
	private String Line2StreetAddress;
	private String City;
	private String State;
	private String Zipcode;
	private String ClaimsBasedHospitalAffiliationLBN1;
	private String ProfessionalAcceptsMedicareAssignment;
	private String ParticipatingeRx;
	private String ParticipatingPQRS;
	private String ParticipatingEHR;

	private String NPI;
	private String MiddleName;
	private String Suffix;
	private String Credential;
	private String GraduationYear;
	private String SecondarySpeciality1;
	private String SecondarySpeciality2;
	private String SecondarySpeciality3;
	private String SecondarySpeciality4;
	private String OrganizationLegalName;
	private String GroupPracticePACID;
	private String NumberofGroupPracticeMembers;
	private String MarkerofAddressLine2Suppression;
	private String ClaimsBasedHospitalAffiliationCCN1;
	private String ClaimsBasedHospitalAffiliationCCN2;
	private String ClaimsBasedHospitalAffiliationLBN2;
	private String ClaimsBasedHospitalAffiliationCCN3;
	private String ClaimsBasedHospitalAffiliationLBN3;
	private String ClaimsBasedHospitalAffiliationCCN4;
	private String ClaimsBasedHospitalAffiliationLBN4;
	private String ClaimsBasedHospitalAffiliationCCN5;
	private String ClaimsBasedHospitalAffiliationLBN5;
	
	
	public String getNPI() {
		return NPI;
	}
	public void setNPI(String npi) {
		this.NPI = npi;
	}
	public String getPACID() {
		return PACID;
	}
	public void setPACID(String pacid) {
		this.PACID = pacid;
	}
	public String getProfessionalEnrollmentID() {
		return ProfessionalEnrollmentID;
	}
	public void setProfessionalEnrollmentID(String professional_Enrollment_ID) {
		this.ProfessionalEnrollmentID = professional_Enrollment_ID;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String last_Name) {
		this.LastName = last_Name;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String first_Name) {
		this.FirstName = first_Name;
	}
	public String getMiddleName() {
		return MiddleName;
	}
	public void setMiddleName(String middle_Name) {
		this.MiddleName = middle_Name;
	}
	public String getSuffix() {
		return Suffix;
	}
	public void setSuffix(String suffix) {
		this.Suffix = suffix;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		this.Gender = gender;
	}
	public String getCredential() {
		return Credential;
	}
	public void setCredential(String credential) {
		this.Credential = credential;
	}
	public String getMedicalSchoolName() {
		return MedicalSchoolName;
	}
	public void setMedicalSchoolName(String medical_school_name) {
		this.MedicalSchoolName = medical_school_name;
	}
	public String getGraduationYear() {
		return GraduationYear;
	}
	public void setGraduationYear(String graduation_year) {
		this.GraduationYear = graduation_year;
	}
	public String getPrimarySpeciality() {
		return PrimarySpeciality;
	}
	public void setPrimarySpeciality(String primary_speciality) {
		this.PrimarySpeciality = primary_speciality;
	}
	public String getSecondarySpeciality1() {
		return SecondarySpeciality1;
	}
	public void setSecondarySpeciality1(String secondaryspecality_1) {
		this.SecondarySpeciality1 = secondaryspecality_1;
	}
	public String getSecondarySpeciality2() {
		return SecondarySpeciality2;
	}
	public void setSecondarySpeciality2(String secondary_speciality_2) {
		this.SecondarySpeciality2 = secondary_speciality_2;
	}
	public String getSecondarySpeciality3() {
		return SecondarySpeciality3;
	}
	public void setSecondarySpeciality3(String seconday_speciality_3) {
		this.SecondarySpeciality3 = seconday_speciality_3;
	}
	public String getSecondarySpeciality4() {
		return SecondarySpeciality4;
	}
	public void setSecondarySpeciality4(String secondary_speciality_4) {
		this.SecondarySpeciality4 = secondary_speciality_4;
	}
	public String getAllSecondarySpecialities() {
		return AllSecondarySpecialities;
	}
	public void setAllSecondarySpecialities(String all_secondary_specialities) {
		this.AllSecondarySpecialities = all_secondary_specialities;
	}
	public String getOrganizationLegalName() {
		return OrganizationLegalName;
	}
	public void setOrganizationLegalName(String organization_legal_name) {
		this.OrganizationLegalName = organization_legal_name;
	}
	public String getGroupPracticePACID() {
		return GroupPracticePACID;
	}
	public void setGroupPracticePACID(String group_Practice_PAC_ID) {
		this.GroupPracticePACID = group_Practice_PAC_ID;
	}
	public String getNumberGroupPracticeMembers() {
		return NumberofGroupPracticeMembers;
	}
	public void setNumberGroupPracticeMembers(String numberPractice_members) {
		this.NumberofGroupPracticeMembers = numberPractice_members;
	}
	public String getLine1StreetAddress() {
		return Line1StreetAddress;
	}
	public void setLine1StreetAddress(String line_1_Street_Address) {
		this.Line1StreetAddress = line_1_Street_Address;
	}
	public String getLine2StreetAddress() {
		return Line2StreetAddress;
	}
	public void setLine2StreetAddress(String line_2_Street_Address) {
		this.Line2StreetAddress = line_2_Street_Address;
	}
	public String getMarkerofAddressLine2Suppression() {
		return MarkerofAddressLine2Suppression;
	}
	public void setMarkerofAddressLine2Suppression(String suppression) {
		this.MarkerofAddressLine2Suppression = suppression;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		this.City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		this.State = state;
	}
	public String getZipcode() {
		return Zipcode;
	}
	public void setZipcode(String zip_code) {
		this.Zipcode = zip_code;
	}
	public String getClaimsBasedHospitalAffiliationCCN1() {
		return ClaimsBasedHospitalAffiliationCCN1;
	}
	public void setClaimsBasedHospitalAffiliationCCN1(String CCN1) {
		this.ClaimsBasedHospitalAffiliationCCN1 = CCN1;
	}
	public String getClaimsBasedHospitalAffiliationLBN1() {
		return ClaimsBasedHospitalAffiliationLBN1;
	}
	public void setClaimsBasedHospitalAffiliationLBN1(String LBN1) {
		this.ClaimsBasedHospitalAffiliationLBN1 = LBN1;
	}
	public String getClaimsBasedHospitalAffiliationCCN2() {
		return ClaimsBasedHospitalAffiliationCCN2;
	}
	public void setClaimsBasedHospitalAffiliationCCN2(String CCN2) {
		this.ClaimsBasedHospitalAffiliationCCN2 = CCN2;
	}
	public String getClaimsBasedHospitalAffiliationLBN2() {
		return ClaimsBasedHospitalAffiliationLBN2;
	}
	public void setClaimsBasedHospitalAffiliationLBN2(String LBN2) {
		this.ClaimsBasedHospitalAffiliationLBN2 = LBN2;
	}
	public String getClaimsBasedHospitalAffiliationCCN3() {
		return ClaimsBasedHospitalAffiliationCCN3;
	}
	public void setClaimsBasedHospitalAffiliationCCN3(String CCN3) {
		this.ClaimsBasedHospitalAffiliationCCN3 = CCN3;
	}
	public String getClaimsBasedHospitalAffiliationLBN3() {
		return ClaimsBasedHospitalAffiliationLBN3;
	}
	public void setClaimsBasedHospitalAffiliationLBN3(String LBN3) {
		this.ClaimsBasedHospitalAffiliationLBN3 = LBN3;
	}
	public String getClaimsBasedHospitalAffiliationCCN4() {
		return ClaimsBasedHospitalAffiliationCCN4;
	}
	public void setClaimsBasedHospitalAffiliationCCN4(String CCN4) {
		this.ClaimsBasedHospitalAffiliationCCN4 = CCN4;
	}
	public String getClaimsBasedHospitalAffiliationLBN4() {
		return ClaimsBasedHospitalAffiliationLBN4;
	}
	public void setClaimsBasedHospitalAffiliationLBN4(String LBN4) {
		this.ClaimsBasedHospitalAffiliationLBN4 = LBN4;
	}
	public String getClaimsBasedHospitalAffiliationCCN5() {
		return ClaimsBasedHospitalAffiliationCCN5;
	}
	public void setClaimsBasedHospitalAffiliationCCN5(String CCN5) {
		this.ClaimsBasedHospitalAffiliationCCN5 = CCN5;
	}
	public String getClaimsBasedHospitalAffiliationLBN5() {
		return ClaimsBasedHospitalAffiliationLBN5;
	}
	public void setClaimsBasedHospitalAffiliationLBN5(String LBN5) {
		this.ClaimsBasedHospitalAffiliationLBN5 = LBN5;
	}
	public String getProfessionalAcceptsMedicareAssignment() {
		return ProfessionalAcceptsMedicareAssignment;
	}
	public void setProfessionalAcceptsMedicareAssignment(String pama) {
		this.ProfessionalAcceptsMedicareAssignment = pama;
	}
	public String getParticipatingeRx() {
		return ParticipatingeRx;
	}
	public void setParticipatingeRx(String participating_in_eRx) {
		this.ParticipatingeRx = participating_in_eRx;
	}
	public String getParticipatingPQRS() {
		return ParticipatingPQRS;
	}
	public void setParticipatingPQRS(String participating_in_PQRS) {
		this.ParticipatingPQRS = participating_in_PQRS;
	}
	public String getParticipatingEHR() {
		return ParticipatingEHR;
	}
	public void setParticipatingEHR(String participating_in_EHR) {
		this.ParticipatingEHR = participating_in_EHR;
	}
	
    public void displayDoctorContent (Doctor doctor){
        System.out.println("De-Serialized Doctor Object ::"+doctor);
        System.out.println("Name ::"+doctor.getFirstName());
        System.out.println("AC_ID - ind_pac_id - " + doctor.getPACID());
        System.out.println("Professional_Enrollment_ID - ind_enrl_id - " + doctor.getProfessionalEnrollmentID());
        System.out.println("Last_Name - lst_nm - " + doctor.getLastName());
        System.out.println("First_Name - frst_nm - " + doctor.getFirstName());
        System.out.println("Gender - gndr - " + doctor.getGender());
        System.out.println("Medical_school_name - med_sch - " + doctor.getMedicalSchoolName());
        System.out.println("Primary_specialty - pri_spec - " + doctor.getPrimarySpeciality());
        System.out.println("All_secondary_specialties - sec_spec_all - " + doctor.getAllSecondarySpecialities());
        System.out.println("Line_1_Street_Address - adr_ln_1 - " + doctor.getLine1StreetAddress());
        System.out.println("Line_2_Street_Address - adr_ln_2 - " + doctor.getLine2StreetAddress());
        System.out.println("City - cty - " + doctor.getCity());
        System.out.println("State - st - " + doctor.getState());
        System.out.println("Zip_Code - zip - " + doctor.getZipcode());
        System.out.println("Claims_based_hospital_affiliation_LBN_1 - hosp_afl_lbn_1 - " + doctor.getClaimsBasedHospitalAffiliationLBN1());
        System.out.println("Professional_accepts_Medicare_Assignment - assgn - " + doctor.getProfessionalAcceptsMedicareAssignment());
        System.out.println("Participating_in_eRx  - erx - " + doctor.getParticipatingeRx());
        System.out.println("Participating_in_PQRS - pqrs - " + doctor.getParticipatingPQRS());
        System.out.println("Participating_in_EHR - ehr - " + doctor.getParticipatingEHR());
        System.out.println("NPI - npi - " + doctor.getNPI());
        System.out.println("Middle_Name - mid_nm - " + doctor.getMiddleName());
        System.out.println("Suffix - suff - " + doctor.getSuffix());
        System.out.println("Credential - cred - " + doctor.getCredential());
        System.out.println("Graduation_year - grd_yr - " + doctor.getGraduationYear());
        System.out.println("Secondaryspecalty_1 - sec_spec_1 - " + doctor.getSecondarySpeciality1());
        System.out.println("Secondary_specialty_2 - sec_spec_2 - " + doctor.getSecondarySpeciality2());
        System.out.println("Seconday_specialty_3 - sec_spec_3 - " + doctor.getSecondarySpeciality3());
        System.out.println("Secondary_specialty_4 - sec_spec_4 - " + doctor.getSecondarySpeciality4());
        System.out.println("Organization_legal_name - org_lgl_nm - " + doctor.getOrganizationLegalName());
        System.out.println("Group_Practice_PAC_ID - org_pac_id - " + doctor.getGroupPracticePACID());
        System.out.println("Number_ofGroup_Practice_members - num_org_mem - " + doctor.getNumberGroupPracticeMembers());
        System.out.println("Marker_of_address_line_2_suppression - ln_2_sprs - " + doctor.getMarkerofAddressLine2Suppression());
        System.out.println("Claims_based_hospital_affiliation_CCN_1 - hosp_afl_1 - " + doctor.getClaimsBasedHospitalAffiliationCCN1());
        System.out.println("Claims_based_hospital_affiliation_CCN_2 - hosp_afl_2 - " + doctor.getClaimsBasedHospitalAffiliationCCN2());
        System.out.println("Claims_based_hospital_affiliation_LBN_2 - hosp_afl_lbn_2 - " + doctor.getClaimsBasedHospitalAffiliationLBN2());
        System.out.println("Claims_based_hospital_affiliation_CCN_3 - hosp_afl_3 - " + doctor.getClaimsBasedHospitalAffiliationCCN3());
        System.out.println("Claims_based_hospital_affiliation_LBN_3 - hosp_afl_lbn_3 - " + doctor.getClaimsBasedHospitalAffiliationLBN3());
        System.out.println("Claims_based_hospital_affiliation_CCN_4 - hosp_afl_4 - " + doctor.getClaimsBasedHospitalAffiliationCCN4());
        System.out.println("Claims_based_hospital_affiliation_LBN_4 - hosp_afl_lbn_4 - " + doctor.getClaimsBasedHospitalAffiliationLBN4());
        System.out.println("Claims_based_hospital_affiliation_CCN_5 - hosp_afl_5 - " + doctor.getClaimsBasedHospitalAffiliationCCN5());
        System.out.println("Claims_based_hospital_affiliation_LBN_5 - hosp_afl_lbn_5 - " + doctor.getClaimsBasedHospitalAffiliationLBN5());
        
        System.out.println("-----------------------------------------------------------------");
        System.out.println("");
    }

}

class DoctorDeserializer implements JsonDeserializer<Doctor> {
	public String checkValue(JsonObject obj, String name) {
		String value="";
		if (obj.has(name)) {
			value = obj.get(name).getAsString();
		}
		return value;
	}
	
    public Doctor deserialize(JsonElement json, Type type, JsonDeserializationContext deserializeContext) throws JsonParseException {
         
        JsonObject jsonObject=json.getAsJsonObject();
        try {
        	if (jsonObject.isJsonNull()) {
        		System.out.println("Doctor Object is Empty");
        		return null;
        	}
	        String ind_pac_id=checkValue(jsonObject,"ind_pac_id");
	        String ind_enrl_id=checkValue(jsonObject,"ind_enrl_id");
	        String lst_nm=checkValue(jsonObject,"lst_nm");
	        String frst_nm=checkValue(jsonObject,"frst_nm");
	        String gndr=checkValue(jsonObject,"gndr");
	        String med_sch=checkValue(jsonObject,"med_sch");
	        String pri_spec=checkValue(jsonObject,"pri_spec");
	        String sec_spec_all=checkValue(jsonObject,"sec_spec_all");
	        String adr_ln_1=checkValue(jsonObject,"adr_ln_1");
	        String adr_ln_2=checkValue(jsonObject,"adr_ln_2");
	        String cty=checkValue(jsonObject,"cty");
	        String st=checkValue(jsonObject,"st");
	        String zip=checkValue(jsonObject,"zip");
	        String hosp_afl_lbn_1=checkValue(jsonObject,"hosp_afl_lbn_1");
	        String assgn=checkValue(jsonObject,"assgn");
	        String erx=checkValue(jsonObject,"erx");
	        String pqrs=checkValue(jsonObject,"pqrs");
	        String ehr=checkValue(jsonObject,"ehr");
	        String npi=checkValue(jsonObject,"npi");
	        String mid_nm=checkValue(jsonObject,"mid_nm");
	        String suff=checkValue(jsonObject,"suff");
	        String cred=checkValue(jsonObject,"cred");
	        String grd_yr=checkValue(jsonObject,"grd_yr");
	        String sec_spec_1=checkValue(jsonObject,"sec_spec_1");
	        String sec_spec_2=checkValue(jsonObject,"sec_spec_2");
	        String sec_spec_3=checkValue(jsonObject,"sec_spec_3");
	        String sec_spec_4=checkValue(jsonObject,"sec_spec_4");
	        String org_lgl_nm=checkValue(jsonObject,"org_lgl_nm");
	        String org_pac_id=checkValue(jsonObject,"org_pac_id");
	        String num_org_mem=checkValue(jsonObject,"num_org_mem");
	        String ln_2_sprs=checkValue(jsonObject,"ln_2_sprs");
	        String hosp_afl_1=checkValue(jsonObject,"hosp_afl_1");
	        String hosp_afl_2=checkValue(jsonObject,"hosp_afl_2");
	        String hosp_afl_lbn_2=checkValue(jsonObject,"hosp_afl_lbn_2");
	        String hosp_afl_3=checkValue(jsonObject,"hosp_afl_3");
	        String hosp_afl_lbn_3=checkValue(jsonObject,"hosp_afl_lbn_3");
	        String hosp_afl_4=checkValue(jsonObject,"hosp_afl_4");
	        String hosp_afl_lbn_4=checkValue(jsonObject,"hosp_afl_lbn_4");
	        String hosp_afl_5=checkValue(jsonObject,"hosp_afl_5");
	        String hosp_afl_lbn_5=checkValue(jsonObject,"hosp_afl_lbn_5");
	        
	    	Doctor doctor=new Doctor();
	        doctor.setPACID(ind_pac_id);
	        doctor.setProfessionalEnrollmentID(ind_enrl_id);
	        doctor.setLastName(lst_nm);
	        doctor.setFirstName(frst_nm);
	        doctor.setGender(gndr);
	        doctor.setMedicalSchoolName(med_sch);
	        doctor.setPrimarySpeciality(pri_spec);
	        doctor.setAllSecondarySpecialities(sec_spec_all);
	        doctor.setLine1StreetAddress(adr_ln_1);
	        doctor.setLine2StreetAddress(adr_ln_2);
	        doctor.setCity(cty);
	        doctor.setState(st);
	        doctor.setZipcode(zip);
	        doctor.setClaimsBasedHospitalAffiliationLBN1(hosp_afl_lbn_1);
	        doctor.setProfessionalAcceptsMedicareAssignment(assgn);
	        doctor.setParticipatingeRx(erx);
	        doctor.setParticipatingPQRS(pqrs);
	        doctor.setParticipatingEHR(ehr);
	        doctor.setNPI(npi);
	        doctor.setMiddleName(mid_nm);
	        doctor.setSuffix(suff);
	        doctor.setCredential(cred);
	        doctor.setGraduationYear(grd_yr);
	        doctor.setSecondarySpeciality1(sec_spec_1);
	        doctor.setSecondarySpeciality2(sec_spec_2);
	        doctor.setSecondarySpeciality3(sec_spec_3);
	        doctor.setSecondarySpeciality4(sec_spec_4);
	        doctor.setOrganizationLegalName(org_lgl_nm);
	        doctor.setGroupPracticePACID(org_pac_id);
	        doctor.setNumberGroupPracticeMembers(num_org_mem);
	        doctor.setMarkerofAddressLine2Suppression(ln_2_sprs);
	        doctor.setClaimsBasedHospitalAffiliationCCN1(hosp_afl_1);
	        doctor.setClaimsBasedHospitalAffiliationCCN2(hosp_afl_2);
	        doctor.setClaimsBasedHospitalAffiliationLBN2(hosp_afl_lbn_2);
	        doctor.setClaimsBasedHospitalAffiliationCCN3(hosp_afl_3);
	        doctor.setClaimsBasedHospitalAffiliationLBN3(hosp_afl_lbn_3);
	        doctor.setClaimsBasedHospitalAffiliationCCN4(hosp_afl_4);
	        doctor.setClaimsBasedHospitalAffiliationLBN4(hosp_afl_lbn_4);
	        doctor.setClaimsBasedHospitalAffiliationCCN5(hosp_afl_5);
	        doctor.setClaimsBasedHospitalAffiliationLBN5(hosp_afl_lbn_5);
	        return doctor;
        } catch (Exception e) {
        	System.out.println("No Doctor Found");
        	return null;        	
        }
    }
}