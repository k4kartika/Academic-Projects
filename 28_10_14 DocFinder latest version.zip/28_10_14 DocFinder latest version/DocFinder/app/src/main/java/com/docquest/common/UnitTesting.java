package com.docquest.common;

import android.util.Log;

import com.docquest.common.util.HTTPRequestHandler;

public class UnitTesting {

	public static void main(String[] args) throws Exception {

        String type = "";
        String category = "-type";


        //Dummy value for Testing Doctor Type
        String[] strParam = {"type=Doctor", "Speciality=","Firstname=REGINALD", "Lastname=SHERRILL", "Zipcode=30342,30338,30326,30786,30720", "City=DALTON","State=GA", "limit=5", "offset=0"};

//        String[] strParam = {"type=Doctor", "Speciality=",
//                "Firstname=REGINALD", "Lastname=SHERRILL",
//                "Zipcode=30342,30338,30326,30786,30720", "City=DALTON",
//                "State=GA", "limit=5", "offset=0"};

        //Dummy value for Testing Hospital Type
//         String[] strParam =
//        {"type=Hospital","name=Northside Hospital","Zipcode=30342,30338,30326,30786,30720",
//         "City=ATLANTA", "State=GA","limit=5","offset=0"};

//        String[] strParam =
//        {"type=Doctor","Zipcode=30342,30338","City=ATLANTA", "State=GA","limit=5","offset=0"};


        try {
            if (args.length <= 0) {
                type = "Hospital";
            } else if (args.length >= 1) {
                if (args[0] == "-type") {
                    type = args[1];
                } else {
                    category = args[0];
                    type = args[1];
                }
            }
            ConditionMaker cm = new ConditionMaker();
            type = "Doctor";
            cm.getData(type, strParam);

        } catch (Exception exception) {
            System.out.println("Error processing file: " + exception);
        }
    }
}

