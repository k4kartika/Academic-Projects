package com.example.jay.docfinder;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


public class SearchHospitalActivity extends ListActivity {

    private ProgressDialog pDialog;

    // URL to get contacts JSON
    //private static String url = "http://api.androidhive.info/contacts/";
    //private static String url = "http://data.medicare.gov/resource/6ibx-ezn8.json";
    //private static String url = "http://data.medicare.gov/resource/xubh-q36u.json?&zip_code=30097&$limit=10&";
    //private static String url = "http://data.medicare.gov/resource/xubh-q36u.json?$limit=10&";
    private static String url = "http://data.medicare.gov/resource/xubh-q36u.json?";
    private static String final_url;

    // JSON Node names
    private static final String TAG_HOSPITAL_NAME = "hospital_name";
    private static final String TAG_ADDRESS = "address";
    private static final String TAG_CITY = "city";
    private static final String TAG_STATE = "state";
    private static final String TAG_ZIPCODE = "zip_code";
    private static final String TAG_PHONE_NUMBER = "phone_number";
    private static final String TAG_HOSPITAL_TYPE = "hospital_type";
    private static final String TAG_PROVIDER_NUMBER = "provider_id";
    private static final String TAG_EMERGENCY_SERVICES = "emergency_services";

    // contacts JSONArray
    JSONObject field = null;
    JSONObject phone = null;

    // Hashmap for ListView
    ArrayList<HashMap<String, String>> contactList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_hospital);

        contactList = new ArrayList<HashMap<String, String>>();

        ListView lv = getListView();
        Intent i = getIntent();
        // getting attached intent data
        String zip_code = i.getStringExtra("zipcode");
        String hos = i.getStringExtra("hospitalname");
        String hospital_name = hos.replaceAll(" ","%20");
        if ((!zip_code.isEmpty()) && (!hospital_name.isEmpty()))
            final_url = url + "&zip_code=" + zip_code + "&$q=" + hospital_name;
        else if ((zip_code.isEmpty()) && (!hospital_name.isEmpty()))
            final_url = url  + "$q=" + hospital_name;
        else if ((!zip_code.isEmpty()) && (hospital_name.isEmpty()))
            final_url = url  + "&zip_code=" + zip_code;
        else
            final_url = url;

        System.out.println("hospital url : " + final_url);


        // Listview on item click listener
        lv.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // getting values from selected ListItem
                String name = ((TextView) view.findViewById(R.id.hospital_name))
                        .getText().toString();

                String haddress = "";
                String hcity = "";
                String hstate = "";
                String zipcode = "";
                String phone = "";
                String type = "";
                String number = "";
                String emergency = "";

                for (HashMap<String, String> map : contactList)  {
                    if(map.get(TAG_HOSPITAL_NAME).contentEquals(name)) {
                        haddress = map.get(TAG_ADDRESS);
                        hcity = map.get(TAG_CITY);
                        hstate = map.get(TAG_STATE);
                        zipcode = map.get(TAG_ZIPCODE);
                        phone = map.get(TAG_PHONE_NUMBER);
                        type = map.get(TAG_HOSPITAL_TYPE);
                        number = map.get(TAG_PROVIDER_NUMBER);
                        emergency = map.get(TAG_EMERGENCY_SERVICES);
                    }

                }

                // Starting single contact activity
                Intent in = new Intent(getApplicationContext(),
                        SingleHospitalActivity.class);
                in.putExtra(TAG_HOSPITAL_NAME, name);
                in.putExtra(TAG_ADDRESS, haddress);
                in.putExtra(TAG_CITY, hcity);
                in.putExtra(TAG_STATE, hstate);
                in.putExtra(TAG_ZIPCODE, zipcode);
                in.putExtra(TAG_PHONE_NUMBER, phone);
                in.putExtra(TAG_HOSPITAL_TYPE, type);
                in.putExtra(TAG_PROVIDER_NUMBER, number);
                in.putExtra(TAG_EMERGENCY_SERVICES, emergency);
                startActivity(in);

            }
        });

        // Calling async task to get json
        new GetContacts().execute();
    }
    /**
     * Async task class to get json by making HTTP call
     * */
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(SearchHospitalActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(final_url, ServiceHandler.GET);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
//                        JSONObject jsonObj = new JSONObject(jsonStr);
                    JSONArray hospitalArr = new JSONArray(jsonStr);

                    // Getting JSON Array node

                    for (int i = 0; i < hospitalArr.length(); i++) {
                        field = hospitalArr.getJSONObject(i);
                        String hospital_name = field.getString(TAG_HOSPITAL_NAME);
                        String haddress = field.getString(TAG_ADDRESS);
                        String hcity = field.getString(TAG_CITY);
                        String hstate = field.getString(TAG_STATE);
                        String zip_code = field.getString(TAG_ZIPCODE);
                        phone = field.getJSONObject(TAG_PHONE_NUMBER);
                        String phone_number = phone.getString(TAG_PHONE_NUMBER);
                        String hospital_type = field.getString(TAG_HOSPITAL_TYPE);
                        String provider_id = field.getString(TAG_PROVIDER_NUMBER);
                        String emergency_services = field.getString(TAG_EMERGENCY_SERVICES);
                        // tmp hashmap for single contact
                        HashMap<String, String> contact = new HashMap<String, String>();

                        // adding each child node to HashMap key => value
                        contact.put(TAG_HOSPITAL_NAME, hospital_name);
                        contact.put(TAG_ADDRESS, haddress);
                        contact.put(TAG_CITY, hcity);
                        contact.put(TAG_STATE, hstate);
                        contact.put(TAG_ZIPCODE, zip_code);
                        contact.put(TAG_PHONE_NUMBER, phone_number);
                        contact.put(TAG_HOSPITAL_TYPE, hospital_type);
                        contact.put(TAG_PROVIDER_NUMBER, provider_id);
                        contact.put(TAG_EMERGENCY_SERVICES, emergency_services);

                        // adding contact to contact list
                        contactList.add(contact);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }

          @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */
            ListAdapter adapter = new SimpleAdapter(
                    SearchHospitalActivity.this, contactList,
                    R.layout.list_view, new String[] { TAG_HOSPITAL_NAME, TAG_ZIPCODE,
                    TAG_ADDRESS }, new int[] { R.id.hospital_name,
                    R.id.zip_code, R.id.haddress });

            setListAdapter(adapter);
        }
    }
}
