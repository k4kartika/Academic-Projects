package com.docquest.common;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
 
public class GsonParentDeserializer {
    public static void main(String[] args) {
    	String jsonParentString="[ {  \"num_org_mem\" : \"1\",  \"ind_enrl_id\" : \"I20050805000904\",  \"npi\" : \"1942286638\",  \"gndr\" : \"F\",  \"frst_nm\" : \"MARI\",  \"lst_nm\" : \"MADSEN\",  \"hosp_afl_lbn_2\" : \"REGENTS UNIV OF CALIF OF LOS ANGELES\",  \"cty\" : \"WEST HOLLYWOOD\",  \"grd_yr\" : \"1999\",  \"mid_nm\" : \"ANNE\",  \"hosp_afl_lbn_1\" : \"CEDARS-SINAI MEDICAL CENTER\",  \"st\" : \"CA\",  \"med_sch\" : \"TUFTS UNIVERSITY SCHOOL OF MEDICINE\",  \"zip\" : \"900481864\",  \"assgn\" : \"Y\",  \"ehr\" : \"Y\",  \"cred\" : \"MD\",  \"sec_spec_1\" : \"GENERAL SURGERY\",  \"hosp_afl_2\" : \"050262\",  \"hosp_afl_1\" : \"050625\",  \"pri_spec\" : \"COLORECTAL SURGERY (PROCTOLOGY)\",  \"erx\" : \"N\",  \"adr_ln_1\" : \"8737 BEVERLY BLVD\",  \"pqrs\" : \"N\",  \"ind_pac_id\" : \"6608805056\",  \"adr_ln_2\" : \"402\",  \"ln_2_sprs\" : \"N\",  \"sec_spec_all\" : \"GENERAL SURGERY\"}, {  \"num_org_mem\" : \"1\",  \"ind_enrl_id\" : \"I20050805000904\",  \"npi\" : \"1942286638\",  \"gndr\" : \"F\",  \"frst_nm\" : \"MARI\",  \"lst_nm\" : \"MADSEN\",  \"hosp_afl_lbn_2\" : \"REGENTS UNIV OF CALIF OF LOS ANGELES\",  \"cty\" : \"WEST HOLLYWOOD\",  \"grd_yr\" : \"1999\",  \"mid_nm\" : \"ANNE\",  \"hosp_afl_lbn_1\" : \"CEDARS-SINAI MEDICAL CENTER\",  \"st\" : \"CA\",  \"med_sch\" : \"TUFTS UNIVERSITY SCHOOL OF MEDICINE\",  \"zip\" : \"900481864\",  \"assgn\" : \"Y\",  \"ehr\" : \"Y\",  \"cred\" : \"MD\",  \"sec_spec_1\" : \"GENERAL SURGERY\",  \"hosp_afl_2\" : \"050262\",  \"hosp_afl_1\" : \"050625\",  \"pri_spec\" : \"COLORECTAL SURGERY (PROCTOLOGY)\",  \"erx\" : \"N\",  \"adr_ln_1\" : \"8737 BEVERLY BLVD\",  \"pqrs\" : \"N\",  \"ind_pac_id\" : \"6608805056\",  \"ln_2_sprs\" : \"N\",  \"sec_spec_all\" : \"GENERAL SURGERY\"} ]";
    	//jsonParentString="[ { }]";
    	//jsonParentString=null;
    	String jsonHospitalString="[{  \"hospital_name\" : \"NORTHSIDE HOSPITAL FORSYTH\",  \"phone_number\" : {    \"phone_number\" : \"4048518700\"  },  \"zip_code\" : \"30041\",  \"location\" : {    \"needs_recoding\" : false,    \"longitude\" : \"-84.13858242899965\",    \"latitude\" : \"34.17882827100044\"},  \"address\" : \"1200 NORTHSIDE FORSYTH DRIVE\",  \"provider_id\" : \"110005\",  \"hospital_ownership\" : \"Voluntary non-profit - Private\",  \"hospital_type\" : \"Acute Care Hospitals\",  \"state\" : \"GA\",  \"emergency_services\" : true,  \"county_name\" : \"FORSYTH\",  \"city\" : \"CUMMING\"}]";
        
    	GsonParentDeserializer g = new GsonParentDeserializer();
    	g.gsonParent(jsonParentString,"Doctor");
    	g.gsonParent(jsonHospitalString,"Hospital");
    }
    
    public Parent gsonParent(String jsonParentString, String type){
        GsonBuilder gsonParentBuilder=new GsonBuilder();
        gsonParentBuilder.registerTypeAdapter(Parent.class, new ParentDeserializer());
        Gson gsonParent=gsonParentBuilder.create();
        Parent parent=gsonParent.fromJson(jsonParentString, Parent.class);
        return parent;
    }
    
    public void createChildList(Parent parent, String type) {
    	if (parent != null) {
    	   for (String child : parent.getParent()) {
    		   	if (child != "" && type.equalsIgnoreCase("Doctor")) {
    		   		Doctor d = gsonChildDoctor(child);
    			    d.displayDoctorContent(d);
    		   } else if (child != "" && type.equalsIgnoreCase("Hospital")){
   		   			Hospital h = gsonChildHospital(child);
   		   			h.displayHospitalContent(h);
       		   } else {
    			   System.out.println("No "+ type + " in the List Returned");
    		   }
     	   }
    	}
	}

	public Doctor gsonChildDoctor(String jsonDoctorString){
        GsonBuilder gsonBuilder=new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Doctor.class, new DoctorDeserializer());
        Gson gson=gsonBuilder.create();
        return gson.fromJson(jsonDoctorString, Doctor.class);
        
    }
	
	public Hospital gsonChildHospital(String jsonHospitalString){
        GsonBuilder gsonBuilder=new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Hospital.class, new HospitalDeserializer());
        Gson gson=gsonBuilder.create();
        return gson.fromJson(jsonHospitalString, Hospital.class);
        
    }
}

class Parent {
    private String[] parent;
     
    public String[] getParent() {
        return parent;
    }
    
    public void setParent(String[] parent) {
        this.parent = parent;
    }
}

class ParentDeserializer implements JsonDeserializer<Parent> {
    public Parent deserialize(JsonElement json, Type type, JsonDeserializationContext deserializeContext) throws JsonParseException {
            
        JsonArray parentArray=json.getAsJsonArray();
        String[] list=new String[parentArray.size()];
         
        for(int index=0;index< list.length;index++) {
        	System.out.println(parentArray.get(index));
        	if (parentArray.get(index)== null) continue;
        	list[index]=parentArray.get(index).getAsJsonObject().toString();
        }
        
        Parent parent=new Parent();
        parent.setParent(list);

        return parent;
    }
}
 